library(testthat)
library(datetimeR)

test_check("datetimeR")
